jQuery.sap.declare("ztest_smart_template.Component");
sap.ui.getCore().loadLibrary("sap.ui.generic.app");
jQuery.sap.require("sap.ui.generic.app.AppComponent");

sap.ui.generic.app.AppComponent.extend("ztest_smart_template.Component", {
	metadata: {
		"manifest": "json"
	}
});